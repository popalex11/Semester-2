#pragma once
#include <assert.h>
#include "dynamicarray.h"

void testCreateDestroyArrayMovieD();
void testAddArrayMovieD();
void testRemoveFromArrayMovieD();
void testSearchInArrayMovieD();