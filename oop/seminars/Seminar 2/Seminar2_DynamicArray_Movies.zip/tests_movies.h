#pragma once
#include <assert.h>
#include "dynamicarray.h"

void testCreateDestroyArrayMovieS();
void testAddArrayMovieS();
void testSetGetElemPosArrayMovieS();
void testRemoveFromArrayMovieS();
void testSearchInArrayMovieS();