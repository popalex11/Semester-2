#pragma once
#include <assert.h>
#include "dynamicarray.h"

void testCreateDestroyArrayMovieD();
void testAddArrayMovieD();
void testSetGetElemPosArray();
void testRemoveFromArrayMovieD();
void testSearchInArrayMovieD();