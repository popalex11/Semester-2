#pragma once
#include <assert.h>
#include "dynamicarray.h"

void testCreateDestroyArray();
void testAddArray();
void testSetGetElemPosArray();
void testRemoveFromArray();
void testSearchInArray();